@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle 9.2.1 or newer is required. Install Gradle, then run this file again.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 exit /b %errorlevel%
echo.
echo Built JARs:
dir /b build\libs\*.jar
pause
